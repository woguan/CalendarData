//
//  NetworkHandler.swift
//  DirectoryApp
//
//  Created by Guan Wong on 9/13/19.
//  Copyright © 2019 Guan Wong. All rights reserved.
//

import Foundation

enum NetworkTrafficType: String {
    case mock
    case source
}

enum NetworkErrorType: Error {
    case serverError
    case responseDenied
    case dataError
    case urlError
}

// Singleton class to handle network traffic
class NetworkHandler {
    
    static let shared = NetworkHandler()
    
    private var type: NetworkTrafficType
    
    private init() {
        type = .source // default hits the backend
    }
    
    func setup(networkType: NetworkTrafficType) {
        type = networkType
    }
    
    func fetchEmployeeList(_ completionHanlder: @escaping (Result<[Employee], NetworkErrorType>) -> Void) {
        downloadEmployeeData { result in
            completionHanlder(result)
        }
    }
    
    func getImageUrl(for url: String) {
        
    }
    
    private func downloadEmployeeData(_ completionhandler: @escaping (Result<[Employee], NetworkErrorType>) -> Void ) {
        guard let url = URL(string: "https://raw.githubusercontent.com/woguan/CalendarData/master/file.json") else {
            completionhandler(.failure(.urlError))
            return
        }
        
        let urlsession = URLSession.shared.dataTask(with: url) { (data, response, error) in
            if error != nil {
                completionhandler(.failure(.serverError))
                return
            }
            
            if let response = response as? HTTPURLResponse, response.statusCode != 200 {
                completionhandler(.failure(.responseDenied))
                return
            }
            
            guard let data = data,
                  let model = try? JSONDecoder().decode(EmployeeModel.self, from: data) else {
                completionhandler(.failure(.dataError))
                return
            }
            
            completionhandler(.success(model.employees))
        }
        
        urlsession.resume()
    }
    
}
