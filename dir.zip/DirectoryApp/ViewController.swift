//
//  ViewController.swift
//  DirectoryApp
//
//  Created by Guan Wong on 9/13/19.
//  Copyright © 2019 Guan Wong. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .green
        
    }
}

