//
//  AllEmployeesListCell.swift
//  DirectoryApp
//
//  Created by Diego Wong on 9/14/19.
//  Copyright © 2019 Guan Wong. All rights reserved.
//

import Foundation
import UIKit

class AllEmployeesListCell: UITableViewCell {
    
}
