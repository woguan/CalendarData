//
//  CommandLineExt.swift
//  DirectoryApp
//
//  Created by Guan Wong on 9/13/19.
//  Copyright © 2019 Guan Wong. All rights reserved.
//

import Foundation

extension CommandLine {
    public static func getValue (for keyEnum: String) -> String? {
        let arg = self.arguments
        return nil
    }
}
