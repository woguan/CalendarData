//
//  NSObjectExt.swift
//  DirectoryApp
//
//  Created by Diego Wong on 9/14/19.
//  Copyright © 2019 Guan Wong. All rights reserved.
//

import Foundation

extension NSObject {
    static var className: String {
        return String(describing: self)
    }
}
