//
//  FilemanagerHandler.swift
//  DirectoryApp
//
//  Created by Diego Wong on 9/13/19.
//  Copyright © 2019 Guan Wong. All rights reserved.
//

import Foundation

let fm = FileManager.default

extension FileManager {
    func docUrl() -> URL? {
        return self.urls(for: .documentDirectory, in: .userDomainMask).first
    }
    
    func docStrUrl() -> String? {
        return self.urls(for: .documentDirectory, in: .userDomainMask).first?.relativePath
    }
}
