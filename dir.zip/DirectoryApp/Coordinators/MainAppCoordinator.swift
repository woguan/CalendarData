//
//  MainCoordinator.swift
//  DirectoryApp
//
//  Created by Diego Wong on 9/13/19.
//  Copyright © 2019 Guan Wong. All rights reserved.
//

import Foundation

import UIKit

class MainAppCoordinator: Coordinator {
    var presenter: UINavigationController
    var coordinator: AllEmployeeListCoordinator?
    private var window: UIWindow
    var employeeList: [Employee] = []
    
    deinit {
        print("deinit")
    }
    
    static let shared = MainAppCoordinator()
    
    private init() {
        self.window = UIWindow(frame: UIScreen.main.bounds)
        presenter = UINavigationController()
    }

    
    func start() {
        
        NetworkHandler.shared.fetchEmployeeList { [weak self] result in

            guard let self = self else {
                return

            }
            
            switch result {
            case .success(let value):
                self.employeeList = value
            case .failure(let error):
                print("Network Error for fetching data: \(error)")
                self.employeeList = []
            }
            
            
            // Do not need to capture self for outter block
            DispatchQueue.main.async {
                self.window.rootViewController = self.presenter
                self.coordinator = AllEmployeeListCoordinator(presenter: self.presenter, employeeList: self.employeeList)
                self.coordinator?.start()
                self.window.makeKeyAndVisible()
            }
        }
    }
    
    
}
