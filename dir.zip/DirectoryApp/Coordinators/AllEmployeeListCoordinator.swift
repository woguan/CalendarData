//
//  AllListEmployeeCoordinator.swift
//  DirectoryApp
//
//  Created by Diego Wong on 9/13/19.
//  Copyright © 2019 Guan Wong. All rights reserved.
//

import Foundation
import UIKit

class AllEmployeeListCoordinator: Coordinator {
    var presenter: UINavigationController
    var employeeList: [Employee]
    var childCoordinator: Coordinator?
    
    init(presenter: UINavigationController, employeeList: [Employee]) {
        self.presenter = presenter
        self.employeeList = employeeList

    }
    
    func start() {
        let allEmployeeListVC = AllEmployeeListViewController()
        allEmployeeListVC.delegate = self
        allEmployeeListVC.employeeList = employeeList
        presenter.pushViewController(allEmployeeListVC, animated: true)
    }
}

extension AllEmployeeListCoordinator: AllEmployeeListViewControllerDelegate {
    func didSelect(employee: Employee) {
        // handle next view for presenting employee data
        print("Selected employee: \(employee.fullName)")
    }
}
