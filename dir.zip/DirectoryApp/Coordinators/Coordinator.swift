//
//  Coordinator.swift
//  DirectoryApp
//
//  Created by Diego Wong on 9/13/19.
//  Copyright © 2019 Guan Wong. All rights reserved.
//

import Foundation
import UIKit

protocol Coordinator {
    var presenter: UINavigationController { get set }
    func start()
}
