//
//  EmployeeModel.swift
//  DirectoryApp
//
//  Created by Guan Wong on 9/13/19.
//  Copyright © 2019 Guan Wong. All rights reserved.
//

import Foundation

enum EmployeeType: String {
    case FULL_TIME
    case PART_TIME
    case CONTRACTOR
    case UNKNOWN
}

struct Employee: Codable {
    // required
    let uuid: String
    let fullName: String
    let emailAdress: String
    let team: String
    let employeeType: EmployeeType
    
    //optional
    let phoneNumber: String?
    let biography: String?
    let photoUrlSmall: String?
    let photoUrlLarge: String?
    
    private enum CodingKeys: String, CodingKey {
        case uuid
        case full_name
        case email_address
        case team
        case employee_type
        case phone_number
        case biography
        case photo_url_small
        case photo_url_large
    }
    
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        uuid = try values.decode(String.self, forKey: .uuid)
        fullName = try values.decode(String.self, forKey: .full_name)
        emailAdress = try values.decode(String.self, forKey: .email_address)
        team = try values.decode(String.self, forKey: .team)
        let type = try values.decode(String.self, forKey: .employee_type)
        employeeType = EmployeeType(rawValue: type) ?? .UNKNOWN
        
        phoneNumber = try values.decodeIfPresent(String.self, forKey: .phone_number)
        biography = try values.decodeIfPresent(String.self, forKey: .biography)
        photoUrlSmall = try values.decodeIfPresent(String.self, forKey: .photo_url_small)
        photoUrlLarge = try values.decodeIfPresent(String.self, forKey: .photo_url_large)
        
    }
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encode(self.uuid, forKey: .uuid)
        try container.encode(self.fullName, forKey: .full_name)
        try container.encode(self.emailAdress, forKey: .email_address)
        try container.encode(self.team, forKey: .team)
        try container.encode(self.employeeType.rawValue, forKey: .employee_type)
        
        try container.encodeIfPresent(self.phoneNumber, forKey: .phone_number)
        try container.encodeIfPresent(self.biography, forKey: .biography)
        try container.encodeIfPresent(self.photoUrlSmall, forKey: .photo_url_small)
        try container.encodeIfPresent(self.photoUrlLarge, forKey: .photo_url_large)
    }
    
    
}

struct EmployeeModel: Codable {
    let employees: [Employee]
}
