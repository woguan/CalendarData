//
//  AllEmployeeListViewController.swift
//  DirectoryApp
//
//  Created by Diego Wong on 9/13/19.
//  Copyright © 2019 Guan Wong. All rights reserved.
//

import Foundation
import UIKit

protocol AllEmployeeListViewControllerDelegate: class {
    func didSelect(employee: Employee)
}

class AllEmployeeListViewController: UIViewController {
    weak var delegate: AllEmployeeListViewControllerDelegate?
    let tableView = UITableView()
    
    var employeeList: [Employee] = [] {
        didSet{
        }
    }
    
    override func loadView() {
        super.loadView()
        view.addSubview(tableView)
        self.setupTableView()
    }
    
    func setupTableView() {
        tableView.translatesAutoresizingMaskIntoConstraints = false
        tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor).isActive = true
        tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor).isActive = true
        tableView.topAnchor.constraint(equalTo: view.layoutMarginsGuide.topAnchor).isActive = true
        tableView.bottomAnchor.constraint(equalTo: view.layoutMarginsGuide.bottomAnchor).isActive = true
        
        tableView.register(AllEmployeesListCell.self, forCellReuseIdentifier:  AllEmployeesListCell.className)
        
        tableView.delegate = self
        tableView.dataSource = self
    }
    
}

extension AllEmployeeListViewController: UITableViewDelegate, UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return employeeList.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        return UITableViewCell()
    }
}
