
=== Architecture ===
Since I have heard that Square does not rely much in storyboard/xibs, I have decided to try out the Coordinator pattern[4] introduced by Soroush Khanlou. This design pattern can help me to handle the navigation flow between ViewControllers.



=== Unit Test ===
Time Spent: ~2hrs 
Focus in building mock network calls used for unit test.
 - Used the environment variables[2] in the target schemes to help me differentiate which network traffic to be used.
 - Casted the response as HTTPURLRESPONSE to get the response code[5]
 - Used Result Type introduced recently to handle completion blocks[6]

=== Caching Policy ===

For profile images, I have decided to save in the memory by using the cache method[3].
 
Initially, I was thinking to store it persistently, so it could display images in offline mode. The only cons for this approach would be occupying a lot of hard disk space of the user. And I would have to come up with an approach to check if the user has the profile image updated. If I wanted to go with this approach, I would need two pieces of detail to build it... which is the user's UUID and the image's UUID. If I detect that the user's profile picture's UUID is not matching with the one locally, I would just need to update it. 

For simplicity and user friendly approach, using the device's memory would be a better move. Thus, I used the NSCache to handle it. 

=== Persistent Storage ===
I have opted to store the Employee list persistently in the disk because it's lightweight compared to the actually assets. 

=== 3rd party framework ===
I have tried to use the minimal dependency possible, but just for fun, I have added the SwiftLint framework to enforce me to stick with Swift Best Practice coding style. 
Since using cocoapods I might need to add some additional steps how to actually build it, I have decided to go with a different approach. I have actually re-used a cool trick from cocoapods to link the frameworks to the project. You can see that the framework is not added in the Embedded Binaries in the pbxproj (usually it would give a 'image not found' if not linked properly)



Sources:
[1] - https://www.hackingwithswift.com/articles/161/how-to-use-result-in-swift
[2] - https://stackoverflow.com/questions/36219597/referring-to-environment-variables-in-swift
[3] - https://www.youtube.com/watch?v=vgoYNswX6C8
[4] - https://www.hackingwithswift.com/articles/71/how-to-use-the-coordinator-pattern-in-ios-apps
[5] - https://dev.to/mishimay/swift-minimum-getpost-request-codes-1085
[6] - https://www.hackingwithswift.com/articles/161/how-to-use-result-in-swift